![poster](./poster.png)
# Poster Shop

## Instruktioner
Du ska koda upp följande givna design av [poster shop](https://www.figma.com/file/ApkqGdPVOlTaKVX6r12bGv/Poster-Shop?node-id=1%3A2).


### Tekniker
Du ska i följande projekt visa att du förstår följande tekniker:
- CSS Flexbox
- CSS Grid


## Screens
![screens](./screens.png)
